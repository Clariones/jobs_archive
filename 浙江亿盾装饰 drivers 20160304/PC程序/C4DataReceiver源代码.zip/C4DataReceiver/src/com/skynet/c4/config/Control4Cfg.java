package com.skynet.c4.config;

public class Control4Cfg {
	private int port;

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
}

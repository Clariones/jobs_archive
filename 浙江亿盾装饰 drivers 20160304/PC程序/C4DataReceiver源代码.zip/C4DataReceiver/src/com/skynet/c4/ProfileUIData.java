package com.skynet.c4;

public class ProfileUIData {
	private String displayName;
	private String name;
	private String startTemplate;
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartTemplate() {
		return startTemplate;
	}
	public void setStartTemplate(String startTemplate) {
		this.startTemplate = startTemplate;
	}
	public String getEndTemplate() {
		return endTemplate;
	}
	public void setEndTemplate(String endTemplate) {
		this.endTemplate = endTemplate;
	}
	private String endTemplate;
}

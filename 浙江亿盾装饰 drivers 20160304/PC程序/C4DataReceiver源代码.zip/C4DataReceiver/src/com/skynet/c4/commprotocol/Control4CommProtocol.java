package com.skynet.c4.commprotocol;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Control4CommProtocol {
	private Control4CommProtocol(){}
	
	public static String msgToString(C4Message c4Msg){
		StringBuffer sb = new StringBuffer();
		sb.append(escapeComma(c4Msg.getCommandCode()));
		if (c4Msg.getSubCommands() != null) {
			for(String subCmd : c4Msg.getSubCommands()){
				sb.append(",").append(escapeComma(subCmd));
			}
		}
		if (c4Msg.getParams() != null){
			Iterator<Entry<String, String>> it = c4Msg.getParams().entrySet().iterator();
			while(it.hasNext()){
				Entry<String, String> ent = it.next();
				sb.append(",").append(escapeComma(ent.getKey())).append("=").append(ent.getValue());
			}
		}
		return sb.toString();
	}

	public static C4Message stringToMsg(String strCmd){
		C4Message rst = new C4Message();
		String[] pieces = strCmd.split(",");
		rst.setCommandCode(unEscapeComma(pieces[0]));
		for(int i=1;i<pieces.length;i++){
			int pos = pieces[i].indexOf("=");
			if (pos > 0){
				String name = pieces[i].substring(0, pos);
				String value = pieces[i].substring(pos+1, pieces[i].length());
				if (rst.getParams() == null){
					rst.setParams(new HashMap<String, String>());
				}
				rst.getParams().put(unEscapeComma(name), unEscapeComma(value));
			}else{
				if (rst.getSubCommands() == null){
					rst.setSubCommands(new ArrayList<String>());
				}
				rst.getSubCommands().add(unEscapeComma(pieces[i]));
			}
		}
		return rst;
	}
	
	public static String escapeComma(String str) {
		return str.replace(",", "&x2C;");
	}
	public static String unEscapeComma(String str) {
		return str.replace("&x2C;", ",");
	}
}

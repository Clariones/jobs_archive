package com.skynet.c4.commprotocol;

import java.util.List;
import java.util.Map;
import java.util.logging.FileHandler;

public class C4Message {
	public static final String CODE_UPDATE_VARIABLE = "UpdateVariable";
	public static final String CODE_UPDATE_DEVICE = "UpdateDevice";
	public static final String CODE_QUERY_DEVICE = "QueryDevice";
	public static final String CODE_RESET_DATA = "ResetData";
	public static final String CODE_EXECUTE_COMMAND = "ExecuteCmd";
	public static final String CODE_TEST_CONNECTION = "TestConnection";
	
	public static final String PARAM_DEVICE_ID = "deviceId";
	public static final String PARAM_DEVICE_NAME = "deviceName";
	public static final String PARAM_DEVICE_PROFILE = "deviceProfile";

	private String commandCode;
	private List<String> subCommands;
	private Map<String, String> params;
	public String getCommandCode() {
		return commandCode;
	}
	public void setCommandCode(String commandCode) {
		this.commandCode = commandCode;
	}
	public List<String> getSubCommands() {
		return subCommands;
	}
	public void setSubCommands(List<String> subCommands) {
		this.subCommands = subCommands;
	}
	public Map<String, String> getParams() {
		return params;
	}
	public void setParams(Map<String, String> params) {
		this.params = params;
	}
}

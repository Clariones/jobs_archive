package com.skynet.c4.datastorage;

import java.util.Map;

import com.skynet.c4.config.DataProcessingCfg;

public class DeviceData {
	private int id;
	private String name;
	private String profile;
	private DataProcessingCfg dataProcessingCfg;
	private Map<String, String> data;
	
	public Map<String, String> getData() {
		return data;
	}
	public void setData(Map<String, String> data) {
		this.data = data;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public DataProcessingCfg getDataProcessingCfg() {
		return dataProcessingCfg;
	}
	public void setDataProcessingCfg(DataProcessingCfg dataProcessingCfg) {
		this.dataProcessingCfg = dataProcessingCfg;
	}
	
	
}

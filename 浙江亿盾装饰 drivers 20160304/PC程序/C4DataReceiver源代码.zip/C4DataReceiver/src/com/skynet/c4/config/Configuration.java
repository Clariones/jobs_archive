package com.skynet.c4.config;

import java.util.List;

public class Configuration {
	private Control4Cfg control4;
	public Control4Cfg getControl4() {
		return control4;
	}
	public void setControl4(Control4Cfg control4) {
		this.control4 = control4;
	}
	public HttpServerCfg getHttpServer() {
		return httpServer;
	}
	public void setHttpServer(HttpServerCfg httpServer) {
		this.httpServer = httpServer;
	}
	public List<DataProcessingCfg> getDataProcessing() {
		return dataProcessing;
	}
	public void setDataProcessing(List<DataProcessingCfg> dataProcessing) {
		this.dataProcessing = dataProcessing;
	}
	private HttpServerCfg httpServer;
	private List<DataProcessingCfg> dataProcessing;
}

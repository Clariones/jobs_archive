package com.skynet.c4;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.logging.Logger;

import com.skynet.c4.config.Configuration;
import com.skynet.c4.config.DataProcessingCfg;
import com.skynet.c4.datastorage.DataStorage;
import com.skynet.c4.datastorage.DeviceData;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;

public class HttpViewRequestHandler implements HttpHandler {

	private Configuration config;
	private Logger logger = Logger.getLogger(HttpViewRequestHandler.class.getName());
	private Template template;

	@Override
	public void handle(HttpExchange httpExchange) throws IOException {
		URI uri = httpExchange.getRequestURI();
		if (uri.getPath().equals("/viewall")) {
			handleViewAll(httpExchange);
			return;
		}
	}

	private void handleViewAll(HttpExchange httpExchange) {
		Map<Integer, DeviceData> allDevcs = DataStorage.getAllDeviceData();
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		Writer out = new OutputStreamWriter(bout);
		try {
			prepareViewAllTemplate();
			Map<String, Object> data = prepareDeviceData(allDevcs);
			template.process(data, out);
			byte[] content = bout.toByteArray();
			httpExchange.sendResponseHeaders(200,content.length);
			OutputStream respOut = httpExchange.getResponseBody(); // 获得输出流  
			respOut.write(content);  
			respOut.flush();  
            httpExchange.close(); 
		} catch (TemplateException | IOException e) {
			e.printStackTrace();
		}
	}

	public Map<String, Object> prepareDeviceData(Map<Integer, DeviceData> allDevcs) {
		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, ProfileUIData> profiles = new HashMap<String, ProfileUIData>();
		final Map<String, DeviceData> devices = new HashMap<String, DeviceData>();
		TreeMap<String, List<String>>  profileGroups = new TreeMap<String, List<String>>();	
		Iterator<Entry<Integer, DeviceData>> it = allDevcs.entrySet().iterator();
		
		while(it.hasNext()){
			Entry<Integer, DeviceData> ent = it.next();
			DeviceData dvcData = ent.getValue();
			String key = "device" + dvcData.getId();
			String profile = dvcData.getProfile();
			if (!profile.equalsIgnoreCase(dvcData.getDataProcessingCfg().getProfile())){
				profile = dvcData.getDataProcessingCfg().getProfile();
			}
			devices.put(key, dvcData);
			List<String> list = profileGroups.get(profile);
			if (list == null){
				list = new ArrayList();
				profileGroups.put(profile, list);
			}
			list.add(key);
			
			DataProcessingCfg profCfg = dvcData.getDataProcessingCfg();
			String profName = profCfg.getProfile();
			ProfileUIData profData = profiles.get(profName);
			if (profData == null){
				profData = new ProfileUIData();
				profiles.put(profName, profData);
			}
			
			if (profData.getName() == null){
				System.out.println("Fill profData " + profName);
				profData.setDisplayName(profCfg.getDisplayName());
				profData.setStartTemplate(profCfg.getStartHtmlTemplate());
				if (profCfg.getDeviceId() <= 0){
					profData.setName(profile);
				}
				profData.setEndTemplate(profCfg.getEndHtmlTemplate());
			}else{
				System.out.println("Skip profData " + profName);
			}
			
			
		}
		
		for(String profile: profileGroups.keySet()){
			Collections.sort(profileGroups.get(profile), new Comparator<String>(){
				@Override
				public int compare(String key1, String key2) {
					String name1 = devices.get(key1).getName();
					String name2 = devices.get(key2).getName();
					return name1.compareTo(name2);
				}});
		}
		data.put("devices", devices);
		data.put("groups", profileGroups);
		data.put("profiles", profiles);
		return data;
	}

	public void setConfig(Configuration config) {
		this.config = config;
		prepareViewAllTemplate();

	}

	public void prepareViewAllTemplate() {
		File templateFile = new File(config.getHttpServer().getViewHtmlTemplate());
		final freemarker.template.Configuration cfg = new freemarker.template.Configuration();
		cfg.setDefaultEncoding("UTF-8");
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
		cfg.setIncompatibleImprovements(new Version(2, 3, 20));
		try {
			cfg.setDirectoryForTemplateLoading(templateFile.getParentFile());
			Template temp = cfg.getTemplate(templateFile.getName());
			logger.config("set template to " + templateFile.getName() + " in the " + templateFile.getParentFile());
			this.template = temp;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

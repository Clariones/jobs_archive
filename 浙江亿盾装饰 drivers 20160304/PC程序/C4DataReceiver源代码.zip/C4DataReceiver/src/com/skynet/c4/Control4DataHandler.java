package com.skynet.c4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.logging.Logger;

import com.skynet.c4.commprotocol.C4Message;
import com.skynet.c4.commprotocol.Control4CommProtocol;
import com.skynet.c4.datastorage.DataStorage;

public class Control4DataHandler {
	private Logger logger = Logger.getLogger(Control4DataHandler.class.getName());

	public String process(String receiveStr) {
		logger.fine(receiveStr);
		C4Message msg = Control4CommProtocol.stringToMsg(receiveStr);
		switch (msg.getCommandCode()) {
		case C4Message.CODE_UPDATE_VARIABLE:
			return handleCmdVarUpdate(msg);
		case C4Message.CODE_UPDATE_DEVICE:
			return handleCmdDeviceUpdate(msg);
		case C4Message.CODE_RESET_DATA:
			return handleCmdResetData(msg);
		case C4Message.CODE_TEST_CONNECTION:
			return handleCmdTestConnection(msg);
		}
		return "Thanks";
	}

	private String handleCmdTestConnection(C4Message msg) {
		msg.getParams().put("responseFrom", this.getClass().getSimpleName());
		return Control4CommProtocol.msgToString(msg);
	}

	private String handleCmdResetData(C4Message msg) {
		DataStorage.resetData();
		return null;
	}

	private String handleCmdDeviceUpdate(C4Message msg) {
		String dvcIdStr = msg.getParams().remove(C4Message.PARAM_DEVICE_ID);
		if (dvcIdStr == null) {
			logger.warning("Invalid device update message: " + Control4CommProtocol.msgToString(msg));
			return null;
		}
		int deviceId = Integer.parseInt(dvcIdStr);
		DataStorage.updateDevice(deviceId, msg.getParams().get(C4Message.PARAM_DEVICE_NAME),
				msg.getParams().get(C4Message.PARAM_DEVICE_PROFILE));
		return null;
	}

	private String handleCmdVarUpdate(C4Message msg) {
		String dvcIdStr = msg.getParams().remove(C4Message.PARAM_DEVICE_ID);
		if (dvcIdStr == null) {
			logger.warning("Invalid variable update message: " + Control4CommProtocol.msgToString(msg));
			return null;
		}
		int deviceId = Integer.parseInt(dvcIdStr);
		boolean alreadyKnowProfile = true;
		Iterator<Entry<String, String>> it = msg.getParams().entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, String> ent = it.next();

			String name = ent.getKey();
			String value = ent.getValue();

			if (name.equalsIgnoreCase(C4Message.PARAM_DEVICE_ID)) {
				continue;
			}

			alreadyKnowProfile = DataStorage.updateDeviceVariable(deviceId, name, value) && alreadyKnowProfile;
		}

		if (alreadyKnowProfile) {
			return null;
		}

		C4Message respMsg = new C4Message();
		respMsg.setCommandCode(C4Message.CODE_QUERY_DEVICE);
		respMsg.setParams(new HashMap<String, String>());
		respMsg.getParams().put(C4Message.PARAM_DEVICE_ID, String.valueOf(deviceId));
		return Control4CommProtocol.msgToString(respMsg);
	}

}

package com.skynet.c4.config;

public class DataProcessingCfg {
	private String profile;
	private String htmlTemplate;
	private int deviceId = -1;
	private String displayName;
	private String startHtmlTemplate;
	private String endHtmlTemplate;
	
	public String getStartHtmlTemplate() {
		return startHtmlTemplate;
	}
	public void setStartHtmlTemplate(String startHtmlTemplate) {
		this.startHtmlTemplate = startHtmlTemplate;
	}
	public String getEndHtmlTemplate() {
		return endHtmlTemplate;
	}
	public void setEndHtmlTemplate(String endHtmlTemplate) {
		this.endHtmlTemplate = endHtmlTemplate;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getHtmlTemplate() {
		return htmlTemplate;
	}
	public void setHtmlTemplate(String htmlTemplate) {
		this.htmlTemplate = htmlTemplate;
	}
	public int getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(int deviceId) {
		this.deviceId = deviceId;
	}
}

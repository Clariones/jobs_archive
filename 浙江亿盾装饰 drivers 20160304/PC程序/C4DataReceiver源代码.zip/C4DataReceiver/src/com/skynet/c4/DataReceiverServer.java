package com.skynet.c4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import com.google.gson.Gson;
import com.skynet.c4.commprotocol.C4Message;
import com.skynet.c4.commprotocol.Control4CommProtocol;
import com.skynet.c4.config.Configuration;
import com.skynet.c4.datastorage.DataStorage;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.spi.HttpServerProvider;

public class DataReceiverServer {
	private Logger logger = Logger.getLogger(DataReceiverServer.class.getName());

	private Configuration config;

	private LinkedBlockingQueue<C4Message> c4SendQueue;

	private boolean connected;

	public void run() {
		loadConfigurations();
		createC4MessageQueues();
		DataStorage.setConfig(config);
		Runnable thread = new Runnable() {
			@Override
			public void run() {
				handleReceivedUDP();
			}
		};
		Thread th = new Thread(thread);
		th.start();
		logger.info("Start listening data from Control4 at port " + config.getControl4().getPort());

		try {
			startHttpServer();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void createC4MessageQueues() {
		// TODO Auto-generated method stub
		LinkedBlockingQueue<C4Message> queue = new LinkedBlockingQueue<C4Message>(100);
		this.c4SendQueue = queue;
	}

	private void startHttpServer() throws IOException {
		HttpServerProvider provider = HttpServerProvider.provider();
		HttpServer httpserver = provider.createHttpServer(new InetSocketAddress(config.getHttpServer().getPort()), 10);
		HttpHandler handler = creatViewHandler();
		httpserver.createContext("/viewall", handler);
		httpserver.createContext("/view/*", handler);
		handler = createCommandHandler();
		httpserver.createContext("/command", handler);
		httpserver.setExecutor(null);
		httpserver.start();
		logger.info("http server started at port " + config.getHttpServer().getPort());
	}

	private HttpHandler createCommandHandler() {
		HttpPostRequestHandler handler = new HttpPostRequestHandler();
		handler.setConfig(config);
		handler.setC4MessageHandler(this);
		return handler;
	}

	private HttpHandler creatViewHandler() {
		HttpViewRequestHandler handler = new HttpViewRequestHandler();
		handler.setConfig(config);
		return handler;
	}

	private void handleReceivedUDP() {
		Control4DataHandler handler = createHandler();
		try {
			InetSocketAddress socketAddr = new InetSocketAddress(config.getControl4().getPort());
			DatagramSocket responseSocket = new DatagramSocket(socketAddr);
			responseSocket.setSoTimeout(1 * 1000);
			byte[] receiveByte = new byte[4 * 1024];
			DatagramPacket dataPacket = new DatagramPacket(receiveByte, receiveByte.length);
			this.connected = false;
			while (true) {
				try {
					responseSocket.receive(dataPacket);
					if (dataPacket.getLength()>0) {
						logger.info("Got data from " + dataPacket.getSocketAddress());
						connected = true;
						String receiveStr = new String(receiveByte, 0, dataPacket.getLength(), Charset.forName("UTF-8"));
						String response = handler.process(receiveStr);
						sendResponse(responseSocket, dataPacket, response);
					}
				} catch (SocketTimeoutException e) {
					logger.finest("Not found data, take a break");
//					continue;
				} catch (IOException e) {
					logger.severe(e.getMessage() + "\nYou need restart the service");
					e.printStackTrace();
					break;
				}

				C4Message msg;
				while (connected && (msg = c4SendQueue.poll()) != null) {
					logger.info("Handle one comamnd");
					String msgStr = Control4CommProtocol.msgToString(msg);
					sendResponse(responseSocket, dataPacket, msgStr);
				}
			}
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	public String pushC4Message(C4Message msg) {
		if (!connected) {
			return "尚未连接到设备，无法下发命令";
		}
		try {
			if (c4SendQueue.offer(msg, 2, TimeUnit.SECONDS)){
				return null;
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return "通讯异常，无法下发命令";
	}

	public void sendResponse(DatagramSocket responseSocket, DatagramPacket dataPacket, String response) {
		if (response == null || response.isEmpty()) {
			return;
		}
		InetAddress cltAddr = dataPacket.getAddress();
		int cltPort = dataPacket.getPort();

		DatagramPacket responsePkt = new DatagramPacket(response.getBytes(), response.length(), cltAddr, cltPort);
		try {
			responseSocket.send(responsePkt);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected Control4DataHandler createHandler() {
		Control4DataHandler rst = new Control4DataHandler();
		return rst;
	}

	private void loadConfigurations() {
		FileReader reader = null;
		try {
			reader = new FileReader("config/configuration.json");
			config = new Gson().fromJson(reader, Configuration.class);
		} catch (FileNotFoundException e) {
			String message = "I want to load " + new File("configuration.json").getAbsolutePath();
			logger.severe(message);
			System.err.println(message);
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
				}
			}
		}

	}

}

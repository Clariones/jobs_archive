package com.skynet.c4.datastorage;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import com.skynet.c4.config.Configuration;
import com.skynet.c4.config.DataProcessingCfg;

public class DataStorage {
	private static Logger logger = Logger.getLogger(DataStorage.class.getName());
	private static Configuration config;
	private static Map<Integer, DeviceData> store = new HashMap<Integer, DeviceData>();
	private static DataProcessingCfg undefinedDataProcessingCfg;
	static {
		undefinedDataProcessingCfg = new DataProcessingCfg();
		undefinedDataProcessingCfg.setDeviceId(0);
		undefinedDataProcessingCfg.setDisplayName("Undefined");
		undefinedDataProcessingCfg.setHtmlTemplate("./NotDefined/html.ftl");
		undefinedDataProcessingCfg.setProfile("undefined");
		undefinedDataProcessingCfg.setStartHtmlTemplate("./NotDefined/startHtml.ftl");
		undefinedDataProcessingCfg.setEndHtmlTemplate("./NotDefined/endHtml.ftl");
	}

	private DataStorage() {
	}

	public static void setConfig(Configuration cfg) {
		config = cfg;
		cfg.getDataProcessing().add(undefinedDataProcessingCfg);
	}

	public static boolean updateDeviceVariable(int deviceId, String name, String value) {
		DeviceData data = store.get(deviceId);
		if (data == null) {
			data = new DeviceData();
			data.setData(new HashMap<String, String>());
			data.setId(deviceId);
			store.put(deviceId, data);
		}
		data.getData().put(name, value);
		return data.getProfile() != null;
	}

	public static void updateDevice(int deviceId, String name, String profile) {
		DeviceData data = store.get(deviceId);
		if (data == null){
			data = new DeviceData();
			data.setData(new HashMap<String, String>());
			data.setId(deviceId);
			store.put(deviceId, data);
		}
		data.setName(name);
		data.setProfile(profile);
		data.setDataProcessingCfg(findDataProcessingCfg(deviceId, profile));
		if (data.getDataProcessingCfg() == null){
			logger.severe("Cannot connect device to profile: " + deviceId+"="+name+" as "+profile);
			data.setDataProcessingCfg(undefinedDataProcessingCfg);
		}
	}

	private static DataProcessingCfg findDataProcessingCfg(int deviceId, String profile) {
		Iterator<DataProcessingCfg> it = config.getDataProcessing().iterator();

		DataProcessingCfg cfgById = null;
		DataProcessingCfg cfgByProfil = null;

		while (it.hasNext()) {
			DataProcessingCfg cfg = it.next();
			if (cfg.getDeviceId() == deviceId) {
				return cfg;
			}
			if (cfg.getProfile().equalsIgnoreCase(profile)) {
				cfgByProfil = cfg;
			}
		}
		return cfgByProfil;
	}

	public static void resetData() {
		store.clear();
	}

	public static Map<Integer, DeviceData> getAllDeviceData() {
		return store;
	}
}

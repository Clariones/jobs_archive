package com.skynet.c4;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.skynet.c4.commprotocol.C4Message;
import com.skynet.c4.commprotocol.Control4CommProtocol;
import com.skynet.c4.config.Configuration;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class HttpPostRequestHandler implements HttpHandler {
	private Logger logger = Logger.getLogger(HttpPostRequestHandler.class.getName());
	private Configuration config;
	private DataReceiverServer c4MsgHandler;

	@Override
	public void handle(HttpExchange httpExchange) throws IOException {
		URI uri = httpExchange.getRequestURI();
		logger.fine("Get request " + uri);
		String urlQuery = uri.getQuery();
		Map<String, List<String>> params = new HashMap();
		parseQuery(uri.getRawQuery(), params);
		InputStream req = httpExchange.getRequestBody();
		StringBuffer sb = new StringBuffer();
		byte[] buffer = new byte[1024];
		while (req.available() > 0) {
			int len = req.read(buffer);
			if (len > 0) {
				sb.append(new String(buffer, 0, len, Charset.forName("UTF-8")));
			}
		}
		parseQuery(sb.toString(), params);

		List<String> commandCode = params.get("commandCode");
		if (commandCode == null || commandCode.size() != 1) {
			responseAlertMsg(httpExchange, "没有commandCode. 命令终止。");
			return;
		}

		List<String> deviceIds = params.get("deviceId");
		if (deviceIds == null || deviceIds.size() != 1) {
			responseAlertMsg(httpExchange, "没有deviceId. 命令终止。");
			return;
		}

		C4Message msg = createC4Message(params);
		if (logger.isLoggable(Level.INFO)) {
			logger.info("Send command " + Control4CommProtocol.msgToString(msg));
		}
		String errMsg = c4MsgHandler.pushC4Message(msg);
		if (errMsg == null){
			errMsg = "命令下发成功";
		}
		responseAlertMsg(httpExchange, errMsg);
	}

	private C4Message createC4Message(Map<String, List<String>> params) {
		String commandCode = params.remove("commandCode").get(0);
		C4Message rst = new C4Message();
		rst.setCommandCode(C4Message.CODE_EXECUTE_COMMAND);
		rst.setSubCommands(new ArrayList<String>());
		rst.getSubCommands().add(commandCode);
		Iterator<Entry<String, List<String>>> it = params.entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, List<String>> ent = it.next();
			String name = ent.getKey();
			List<String> values = ent.getValue();
			String value = "";
			if (values != null && values.size() == 1) {
				value = values.get(0);
			} else if (values == null || values.size() == 0) {
				value = "";
			} else {
				value = values.get(0);
				for (int i = 1; i < values.size(); i++) {
					value = value + "," + values.get(i);
				}
			}

			if (rst.getParams() == null) {
				rst.setParams(new HashMap<String, String>());
			}
			rst.getParams().put(name, value);
		}
		return rst;
	}

	public void responseAlertMsg(HttpExchange httpExchange, String message) throws IOException {
		String data = "<html><body><script type=\"text/javascript\">\n alert(\"" + message
				+ "\"); \n</script></body></html>";
		httpExchange.sendResponseHeaders(200, data.getBytes().length);
		OutputStream respOut = httpExchange.getResponseBody(); // 获得输出流
		respOut.write(data.getBytes());
		respOut.flush();
		httpExchange.close();
	}

	private void parseQuery(String rawQuery, Map<String, List<String>> params) {
		if (rawQuery == null || rawQuery.isEmpty()) {
			return;
		}
		String[] pieces = rawQuery.split("\\&");
		for (int i = 0; i < pieces.length; i++) {
			int pos = pieces[i].indexOf('=');
			if (pos < 0) {
				try {
					saveParam(params, URLDecoder.decode(pieces[i], "UTF-8"), "");
				} catch (UnsupportedEncodingException e) {
				}
			} else {
				String name = pieces[i].substring(0, pos);
				String value = pieces[i].substring(pos + 1);
				try {
					saveParam(params, URLDecoder.decode(name, "UTF-8"), URLDecoder.decode(value, "UTF-8"));
				} catch (UnsupportedEncodingException e) {
				}
			}
		}

	}

	private void saveParam(Map<String, List<String>> params, String name, String value) {
		List<String> list = params.get(name);
		if (list == null) {
			list = new ArrayList<String>();
			params.put(name, list);
		}
		list.add(value);
	}

	public void setConfig(Configuration config) {
		this.config = config;
	}

	public void setC4MessageHandler(DataReceiverServer handler) {
		this.c4MsgHandler = handler;
	}

}

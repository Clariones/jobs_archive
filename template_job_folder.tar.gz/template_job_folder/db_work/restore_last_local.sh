export BASE_FOLDER="$( cd "$( dirname "$0"  )/.." && pwd  )"
source ${BASE_FOLDER}/project_config/project.env.sh
cd ${BASE_FOLDER}/db_work
filename=`ls -l bettbio_ad_v2_dump*.sql -ltr | tail -1 | awk '{print $9}'`
echo "restore from ${filename}"
mysql -uroot -p0254891276 ${DB_SCHEMA} < ${filename}

export BASE_FOLDER="$( cd "$( dirname "$0"  )/.." && pwd  )"
source ${BASE_FOLDER}/project_config/project.env.sh
mysqldump -uroot -p0254891276 ${DB_SCHEMA} > ${DB_SCHEMA}_dump`date +%Y%m%d_%H%M%S`.sql


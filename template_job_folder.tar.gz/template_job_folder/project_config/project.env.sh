export BASE_FOLDER="$( cd "$( dirname "$0"  )/.." && pwd  )"
export DB_SCHEMA=my_task_board
export PRJ_HOME=/space/jobs/my_task_board
